<?php
function nav_icon(string $name): string {
    $icons = [
      'dashboard' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></svg>',
      'transaksi' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h16v17l-2-1.5L16 21l-2-1.5L12 21l-2-1.5L8 21l-2-1.5L4 21z"/><path d="M8 9h8M8 13h8M8 17h4"/></svg>',
      'laporan' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h8l4 4v14H6z"/><path d="M14 3v5h5M9 12h6M9 16h6"/></svg>',
      'produk' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h16l-1 13H5z"/><path d="M8 8V6a4 4 0 0 1 8 0v2M9 12v5M15 12v5"/></svg>',
      'users' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    ];
    return $icons[$name] ?? '';
}
function header_ui(string $title, string $active=''): void {
    $u = $_SESSION['user'];
    $nav = [
      ['index.php','Dashboard','dashboard'],
    ];
    if ($u['role']==='kasir') $nav[]=['transaksi.php','Transaksi Baru','transaksi'];
    $nav[]=['laporan.php','Laporan','laporan'];
    if ($u['role']==='admin') { $nav[]=['produk.php','Menu & Stok','produk']; $nav[]=['users.php','Kelola Akun','users']; }
    echo '<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.e($title).' | Titik Temu Kopi</title><link rel="stylesheet" href="assets/style.css"></head><body><div class="app-shell"><aside class="sidebar"><div class="brand"><span class="brand-mark small">☕</span><div><b>Titik Temu</b><small>KOPI &amp; MAKANAN</small></div></div><nav>';
    foreach($nav as $n) echo '<a class="'.($active===$n[2]?'active':'').'" href="'.$n[0].'"><span class="nav-icon">'.nav_icon($n[2]).'</span><span>'.$n[1].'</span></a>';
    echo '</nav></aside><main class="main"><div class="cafe-ribbon"><div class="cafe-ribbon-icon">☕</div><div class="cafe-ribbon-copy"><b>Titik Temu Kopi</b><small>Kopi • Makanan • Cerita</small></div><div class="cafe-ribbon-food">🥐</div></div><header class="topbar"><div><p class="eyebrow">MANAJEMEN KAFE</p><h1>'.e($title).'</h1></div><div class="topbar-right"><div class="today">'.date('d M Y').'</div><details class="profile-menu"><summary><span class="avatar">'.e(strtoupper(substr($u['name'],0,1))).'</span><span class="profile-menu-name"><b>'.e($u['name']).'</b><small>'.e(ucfirst($u['role'])).'</small></span><span class="profile-chevron">⌄</span></summary><div class="profile-dropdown"><a href="logout.php" class="profile-logout">↪ &nbsp; Logout</a></div></details></div></header>';
    if (!empty($_SESSION['flash'])) { $f=$_SESSION['flash']; unset($_SESSION['flash']); echo '<div class="alert '.e($f['type']).'">'.e($f['message']).'</div>'; }
}
function footer_ui(): void { echo '</main></div><script src="assets/app.js"></script></body></html>'; }
