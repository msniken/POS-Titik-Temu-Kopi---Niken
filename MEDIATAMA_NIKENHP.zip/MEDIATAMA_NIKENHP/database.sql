CREATE DATABASE IF NOT EXISTS pos_titik_temu CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pos_titik_temu;

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(60) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 nama_lengkap VARCHAR(120) NOT NULL,
 role ENUM('admin','kasir') NOT NULL DEFAULT 'kasir',
 status TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nama_kategori VARCHAR(80) NOT NULL UNIQUE,
 slug VARCHAR(100) NOT NULL UNIQUE,
 status TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
 id INT AUTO_INCREMENT PRIMARY KEY,
 category_id INT NOT NULL,
 kode_produk VARCHAR(30) NOT NULL UNIQUE,
 nama_produk VARCHAR(120) NOT NULL,
 harga_jual DECIMAL(12,2) NOT NULL DEFAULT 0,
 harga_pokok DECIMAL(12,2) NOT NULL DEFAULT 0,
 stok INT NOT NULL DEFAULT 0,
 stok_minimum INT NOT NULL DEFAULT 5,
 unit VARCHAR(20) NOT NULL DEFAULT 'item',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_products_category FOREIGN KEY(category_id) REFERENCES categories(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 invoice_number VARCHAR(40) NOT NULL UNIQUE,
 user_id INT NOT NULL,
 tipe_pesanan ENUM('Dine-In','Takeaway') NOT NULL,
 nomor_meja VARCHAR(20) NULL,
 nama_pemesan VARCHAR(120) NULL,
 total_subtotal DECIMAL(12,2) NOT NULL,
 pajak_nominal DECIMAL(12,2) NOT NULL,
 diskon_nominal DECIMAL(12,2) NOT NULL DEFAULT 0,
 grand_total DECIMAL(12,2) NOT NULL,
 metode_bayar ENUM('Tunai','QRIS','Transfer Bank','Kartu Debit') NOT NULL,
 uang_dibayar DECIMAL(12,2) NOT NULL DEFAULT 0,
 uang_kembali DECIMAL(12,2) NOT NULL DEFAULT 0,
 status ENUM('Diproses','Selesai','Dibatalkan') NOT NULL DEFAULT 'Selesai',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_orders_user FOREIGN KEY(user_id) REFERENCES users(id),
 INDEX idx_orders_created_status(created_at,status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_details (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 order_id BIGINT NOT NULL,
 product_id INT NOT NULL,
 harga_satuan DECIMAL(12,2) NOT NULL,
 kuantiti INT NOT NULL,
 subtotal_baris DECIMAL(12,2) NOT NULL,
 catatan_khusus VARCHAR(255) NULL,
 CONSTRAINT fk_details_order FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
 CONSTRAINT fk_details_product FOREIGN KEY(product_id) REFERENCES products(id)
) ENGINE=InnoDB;

INSERT IGNORE INTO categories (nama_kategori,slug) VALUES
('Coffee','coffee'),('Non-Coffee','non-coffee'),('Food','food'),('Pastry','pastry');

-- Akun demo: admin / admin dan kasir / kasir.
-- Hash dibuat menggunakan fungsi PHP password_hash().
INSERT INTO users(username,password_hash,nama_lengkap,role,status) VALUES
('admin','$2y$12$1uGZZewb0GTE1IxSJHYC.u1KAoBQECY2fEvGm.9bZxrVOqYZnZfp6','Administrator','admin',1),
('kasir','$2y$12$lZa7ePgTLzpkrHdVrqR4X.AAzVLBtNYKkx7wSd5IEsK7Td9qUI3Pi','Niken','kasir',1)
ON DUPLICATE KEY UPDATE password_hash=VALUES(password_hash), nama_lengkap=VALUES(nama_lengkap), role=VALUES(role), status=1;

INSERT IGNORE INTO products(category_id,kode_produk,nama_produk,harga_jual,harga_pokok,stok,stok_minimum,unit)
SELECT id,'CF001','Espresso',18000,7000,40,8,'cup' FROM categories WHERE slug='coffee';
INSERT IGNORE INTO products(category_id,kode_produk,nama_produk,harga_jual,harga_pokok,stok,stok_minimum,unit)
SELECT id,'CF002','Kopi Susu Gula Aren',25000,10000,30,8,'cup' FROM categories WHERE slug='coffee';
INSERT IGNORE INTO products(category_id,kode_produk,nama_produk,harga_jual,harga_pokok,stok,stok_minimum,unit)
SELECT id,'NC001','Matcha Latte',28000,12000,20,5,'cup' FROM categories WHERE slug='non-coffee';
INSERT IGNORE INTO products(category_id,kode_produk,nama_produk,harga_jual,harga_pokok,stok,stok_minimum,unit)
SELECT id,'FD001','Chicken Rice Bowl',35000,18000,15,5,'porsi' FROM categories WHERE slug='food';
INSERT IGNORE INTO products(category_id,kode_produk,nama_produk,harga_jual,harga_pokok,stok,stok_minimum,unit)
SELECT id,'PS001','Croissant',22000,9000,12,4,'pcs' FROM categories WHERE slug='pastry';
