<?php
require __DIR__.'/config.php';
require_login();
require __DIR__.'/partials.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $nama = trim($_POST['nama_lengkap'] ?? '');
    if ($nama === '' || mb_strlen($nama) > 120) {
        $error = 'Nama wajib diisi dan maksimal 120 karakter.';
    } else {
        $stmt = $pdo->prepare('UPDATE users SET nama_lengkap = ? WHERE id = ?');
        $stmt->execute([$nama, $_SESSION['user']['id']]);
        $_SESSION['user']['name'] = $nama;
        flash('Nama pengguna berhasil diperbarui. Nama pada struk dan dashboard juga akan mengikuti.', 'success');
        redirect('profil.php');
    }
}
header_ui('Profil Pengguna', '');
?>
<section class="panel profile-edit-panel">
  <div class="panel-heading"><div><h3>Ubah nama kasir/pengguna</h3><p class="muted">Nama ini akan tampil pada struk dan kolom Kasir di Dashboard.</p></div></div>
  <?php if ($error): ?><div class="alert error"><?=e($error)?></div><?php endif; ?>
  <form method="post" class="profile-edit-form">
    <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
    <label for="nama_lengkap">Nama yang ditampilkan</label>
    <input id="nama_lengkap" name="nama_lengkap" maxlength="120" value="<?=e($_SESSION['user']['name'])?>" required>
    <small class="muted">Contoh: Niken, Niken Handayani, atau nama kasir lainnya.</small>
    <div class="actions profile-edit-actions"><button class="btn" type="submit">Simpan Nama</button><a href="index.php" class="btn btn-light">Kembali</a></div>
  </form>
</section>
<?php footer_ui(); ?>
