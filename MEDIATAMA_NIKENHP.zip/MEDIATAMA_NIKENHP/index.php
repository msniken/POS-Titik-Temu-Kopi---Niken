<?php
require __DIR__.'/config.php'; require_login(); require __DIR__.'/partials.php';
$today = date('Y-m-d');
$stmt=$pdo->prepare("SELECT COALESCE(SUM(grand_total),0) omzet, COUNT(*) jumlah FROM orders WHERE DATE(created_at)=? AND status='Selesai'");
$stmt->execute([$today]); $kpi=$stmt->fetch();
$top=$pdo->query("SELECT p.nama_produk,COALESCE(SUM(d.kuantiti),0) qty FROM order_details d JOIN products p ON p.id=d.product_id JOIN orders o ON o.id=d.order_id WHERE o.status='Selesai' AND DATE(o.created_at)=CURDATE() GROUP BY p.id ORDER BY qty DESC LIMIT 1")->fetch();
$low=$pdo->query("SELECT COUNT(*) n FROM products WHERE stok<=stok_minimum")->fetch()['n'];
$recent=$pdo->query("SELECT o.*,u.nama_lengkap FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC LIMIT 7")->fetchAll();
$chart=$pdo->query("SELECT DATE(created_at) hari, SUM(grand_total) total FROM orders WHERE status='Selesai' AND created_at>=DATE_SUB(CURDATE(),INTERVAL 6 DAY) GROUP BY DATE(created_at)")->fetchAll();
$chartMap=[]; foreach($chart as $c) $chartMap[$c['hari']]=(float)$c['total'];
header_ui('Dashboard','dashboard');
?>
<div class="welcome-row"><div><h2>Ringkasan operasional</h2><p class="muted">Pantau performa kafe hari ini.</p></div><?php if($_SESSION['user']['role']==='kasir'): ?><a class="btn" href="transaksi.php">＋ Transaksi Baru</a><?php else: ?><a class="btn" href="users.php">＋ Kelola Akun Pengguna</a><?php endif; ?></div>
<div class="kpi-grid">
 <div class="kpi-card"><div class="kpi-label">Total Omzet Hari Ini <span class="kpi-icon">↗</span></div><div class="kpi-value"><?=rupiah($kpi['omzet'])?></div><small class="muted">Transaksi berstatus selesai</small></div>
 <div class="kpi-card"><div class="kpi-label">Pesanan Selesai <span class="kpi-icon">▤</span></div><div class="kpi-value"><?=number_format((int)$kpi['jumlah'])?></div><small class="muted">Hari ini</small></div>
 <div class="kpi-card"><div class="kpi-label">Menu Terlaris <span class="kpi-icon">☕</span></div><div class="kpi-value medium"><?=e($top['nama_produk']??'Belum ada data')?></div><small class="muted"><?=isset($top['qty'])?(int)$top['qty'].' item terjual hari ini':'Data penjualan akan tampil di sini'?></small></div>
 <div class="kpi-card warning-card"><div class="kpi-label">Stok Perlu Dicek <span class="kpi-icon">!</span></div><div class="kpi-value"><?=number_format((int)$low)?> item</div><small class="muted">Stok sama dengan/di bawah batas minimum</small></div>
</div>
<div class="content-grid"><section class="panel"><div class="panel-heading"><div><h3>Tren Penjualan</h3><p class="muted">7 hari terakhir</p></div><span class="tag">Omzet</span></div><div class="chart">
<?php for($i=6;$i>=0;$i--): $day=date('Y-m-d',strtotime("-$i days")); $val=$chartMap[$day]??0; $max=max(1,...array_values($chartMap?:[1])); $height=max(4,round($val/$max*130)); ?>
<div class="bar-column"><div class="bar-value"><?= $val ? e(number_format($val/1000,0)).'k' : '' ?></div><div class="bar" style="height:<?=$height?>px"></div><small><?=date('d/m',strtotime($day))?></small></div>
<?php endfor; ?></div></section>
<section class="panel"><div class="panel-heading"><div><h3>Perlu Perhatian</h3><p class="muted">Pantau stok bahan/menu</p></div></div>
<?php $lowItems=$pdo->query("SELECT nama_produk,stok,stok_minimum FROM products WHERE stok<=stok_minimum ORDER BY stok ASC LIMIT 5")->fetchAll(); if(!$lowItems): ?><div class="empty-state">✓ Semua stok berada di atas batas minimum.</div><?php else: foreach($lowItems as $p): ?><div class="stock-row"><div><b><?=e($p['nama_produk'])?></b><small>Minimum <?=e($p['stok_minimum'])?> item</small></div><span class="stock-pill"><?=e($p['stok'])?> tersisa</span></div><?php endforeach; endif; ?>
<?php if($_SESSION['user']['role']==='admin'): ?><a class="text-link" href="produk.php">Kelola menu & stok →</a><?php endif; ?></section></div>
<section class="panel table-panel"><div class="panel-heading"><div><h3>Transaksi Terbaru</h3><p class="muted">7 aktivitas terbaru</p></div><a class="text-link" href="laporan.php">Lihat laporan →</a></div><div class="table-wrap"><table><thead><tr><th>Invoice</th><th>Waktu</th><th>Kasir</th><th>Tipe</th><th>Total</th><th>Status</th></tr></thead><tbody>
<?php if(!$recent): ?><tr><td colspan="6" class="empty-cell">Belum ada transaksi.</td></tr><?php endif; foreach($recent as $r): ?><tr><td class="mono"><?=e($r['invoice_number'])?></td><td><?=date('d/m/Y H:i',strtotime($r['created_at']))?></td><td><?=e($r['nama_lengkap'])?></td><td><?=e($r['tipe_pesanan'])?></td><td><b><?=rupiah($r['grand_total'])?></b></td><td><span class="status <?=strtolower(str_replace(' ','-',$r['status']))?>"><?=e($r['status'])?></span></td></tr><?php endforeach; ?>
</tbody></table></div></section>
<?php footer_ui(); ?>
