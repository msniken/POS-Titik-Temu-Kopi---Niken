<?php
require __DIR__.'/config.php'; require_login(); require __DIR__.'/partials.php';
$from=$_GET['from']??date('Y-m-01'); $to=$_GET['to']??date('Y-m-d'); $cat=(int)($_GET['category']??0); $method=$_GET['method']??'';
$where=["DATE(o.created_at)>=?","DATE(o.created_at)<=?","o.status='Selesai'"]; $params=[$from,$to];
if($cat>0){$where[]="EXISTS(SELECT 1 FROM order_details dx JOIN products px ON px.id=dx.product_id WHERE dx.order_id=o.id AND px.category_id=?)";$params[]=$cat;}
if(in_array($method,['Tunai','QRIS','Transfer Bank','Kartu Debit'],true)){$where[]='o.metode_bayar=?';$params[]=$method;}
$sql='SELECT o.*,u.nama_lengkap, (SELECT GROUP_CONCAT(CONCAT(p.nama_produk," ×",d.kuantiti) SEPARATOR ", ") FROM order_details d JOIN products p ON p.id=d.product_id WHERE d.order_id=o.id) items FROM orders o JOIN users u ON u.id=o.user_id WHERE '.implode(' AND ',$where).' ORDER BY o.created_at DESC';
$stmt=$pdo->prepare($sql);$stmt->execute($params);$rows=$stmt->fetchAll();
$sum=['gross'=>0,'discount'=>0,'tax'=>0,'net'=>0];foreach($rows as $r){$sum['gross']+=$r['total_subtotal'];$sum['discount']+=$r['diskon_nominal'];$sum['tax']+=$r['pajak_nominal'];$sum['net']+=$r['grand_total'];}
$avg=count($rows)?$sum['net']/count($rows):0;
$categories=$pdo->query('SELECT id,nama_kategori FROM categories ORDER BY nama_kategori')->fetchAll();
if(($_GET['export']??'')==='csv'){
 header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="laporan-pos.csv"');
 $out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");fputcsv($out,['Invoice','Tanggal','Kasir','Tipe Pesanan','Item Terjual','Subtotal','Diskon','Pajak','Grand Total','Metode','Status']);
 foreach($rows as $r) fputcsv($out,[$r['invoice_number'],$r['created_at'],$r['nama_lengkap'],$r['tipe_pesanan'],$r['items'],$r['total_subtotal'],$r['diskon_nominal'],$r['pajak_nominal'],$r['grand_total'],$r['metode_bayar'],$r['status']]);
 fclose($out);exit;
}
header_ui('Laporan Penjualan','laporan');
?>
<section class="panel"><div class="panel-heading"><div><h3>Filter Laporan</h3><p class="muted">Pilih periode dan parameter transaksi.</p></div></div>
<form method="get" class="report-filter"><div><label>Dari Tanggal</label><input type="date" name="from" value="<?=e($from)?>" required></div><div><label>Sampai Tanggal</label><input type="date" name="to" value="<?=e($to)?>" required></div><div><label>Kategori Menu</label><select name="category"><option value="0">Semua kategori</option><?php foreach($categories as $c): ?><option value="<?=$c['id']?>" <?=$cat===$c['id']?'selected':''?>><?=e($c['nama_kategori'])?></option><?php endforeach; ?></select></div><div><label>Metode Bayar</label><select name="method"><option value="">Semua metode</option><?php foreach(['Tunai','QRIS','Transfer Bank','Kartu Debit'] as $m): ?><option <?=$method===$m?'selected':''?>><?=$m?></option><?php endforeach; ?></select></div><button class="btn">Terapkan Filter</button></form></section>
<div class="kpi-grid report-kpis"><div class="kpi-card"><div class="kpi-label">Omzet Bruto</div><div class="kpi-value"><?=rupiah($sum['gross'])?></div></div><div class="kpi-card"><div class="kpi-label">Diskon Diberikan</div><div class="kpi-value"><?=rupiah($sum['discount'])?></div></div><div class="kpi-card"><div class="kpi-label">Pajak Terkumpul</div><div class="kpi-value"><?=rupiah($sum['tax'])?></div></div><div class="kpi-card"><div class="kpi-label">Omzet Bersih</div><div class="kpi-value"><?=rupiah($sum['net'])?></div><small class="muted">Rata-rata: <?=rupiah($avg)?></small></div></div>
<section class="panel table-panel"><div class="panel-heading"><div><h3>Data Transaksi</h3><p class="muted"><?=count($rows)?> transaksi ditemukan</p></div><a class="btn btn-light" href="?<?=http_build_query(['from'=>$from,'to'=>$to,'category'=>$cat,'method'=>$method,'export'=>'csv'])?>">↓ Ekspor CSV</a></div><div class="table-wrap"><table><thead><tr><th>Invoice</th><th>Tanggal & Jam</th><th>Kasir</th><th>Tipe</th><th>Item Terjual</th><th>Subtotal</th><th>Pajak</th><th>Grand Total</th><th>Status</th></tr></thead><tbody><?php if(!$rows): ?><tr><td colspan="9" class="empty-cell">Tidak ada transaksi untuk filter ini.</td></tr><?php endif; foreach($rows as $r): ?><tr><td class="mono"><?=e($r['invoice_number'])?></td><td><?=date('d/m/Y H:i',strtotime($r['created_at']))?></td><td><?=e($r['nama_lengkap'])?></td><td><?=e($r['tipe_pesanan'])?></td><td><?=e($r['items'])?></td><td><?=rupiah($r['total_subtotal'])?></td><td><?=rupiah($r['pajak_nominal'])?></td><td><b><?=rupiah($r['grand_total'])?></b></td><td><span class="status selesai">Selesai</span></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php footer_ui(); ?>
