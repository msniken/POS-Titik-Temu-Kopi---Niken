(() => {
 const form = document.getElementById('order-form');
 if (!form) return;
 const items = document.getElementById('items');
 const type = document.getElementById('order-type');
 const tableField = document.getElementById('table-field');
 const method = document.getElementById('payment-method');
 const cashFields = document.getElementById('cash-fields');
 const discount = document.getElementById('discount');
 const paid = document.getElementById('paid');
 const money = n => 'Rp ' + Math.round(n || 0).toLocaleString('id-ID');
 const optionData = select => {
   const opt = select.options[select.selectedIndex];
   return {price: Number(opt?.dataset.price || 0), stock: Number(opt?.dataset.stock || 0)};
 };
 function update() {
   let subtotal = 0;
   items.querySelectorAll('.order-item').forEach(row => {
     const select = row.querySelector('.product-select');
     const qty = row.querySelector('.qty-input');
     const data = optionData(select);
     if (data.stock > 0) qty.max = data.stock;
     const line = data.price * Math.max(0, Number(qty.value || 0));
     subtotal += line;
     row.querySelector('.line-total').textContent = 'Subtotal: ' + money(line);
   });
   const disc = Math.min(subtotal, Math.max(0, Number(discount.value || 0)));
   const tax = (subtotal - disc) * .10;
   const total = subtotal - disc + tax;
   document.getElementById('subtotal-view').textContent = money(subtotal);
   document.getElementById('tax-view').textContent = money(tax);
   document.getElementById('grand-view').textContent = money(total);
   document.getElementById('change-view').textContent = money(Math.max(0, Number(paid.value || 0) - total));
   if (method.value !== 'Tunai') {
     cashFields.classList.add('hidden');
     paid.value = Math.round(total);
   } else {
     cashFields.classList.remove('hidden');
   }
 }
 function attach(row) {
   row.querySelectorAll('select,input').forEach(el => el.addEventListener('input', update));
   row.querySelector('.remove-item').addEventListener('click', () => {
     if (items.querySelectorAll('.order-item').length > 1) row.remove();
     else {
       row.querySelector('.product-select').value = '';
       row.querySelector('.qty-input').value = 1;
       row.querySelector('input[name="catatan[]"]').value = '';
     }
     update();
   });
 }
 const first = items.querySelector('.order-item');
 attach(first);
 document.getElementById('add-item').addEventListener('click', () => {
   const clone = first.cloneNode(true);
   clone.querySelector('.product-select').value = '';
   clone.querySelector('.qty-input').value = 1;
   clone.querySelector('input[name="catatan[]"]').value = '';
   items.appendChild(clone); attach(clone); update();
 });
 type.addEventListener('change', () => tableField.classList.toggle('hidden', type.value !== 'Dine-In'));
 method.addEventListener('change', update);
 discount.addEventListener('input', update);
 paid.addEventListener('input', update);
 form.addEventListener('submit', ev => {
   const seen = {};
   for (const row of items.querySelectorAll('.order-item')) {
     const sel = row.querySelector('.product-select');
     const qty = row.querySelector('.qty-input');
     if (!sel.value || Number(qty.value) < 1) { ev.preventDefault(); alert('Pilih menu dan kuantitas minimal 1.'); return; }
     const d = optionData(sel);
     seen[sel.value] = (seen[sel.value] || 0) + Number(qty.value);
     if (seen[sel.value] > d.stock) { ev.preventDefault(); alert('Jumlah '+sel.options[sel.selectedIndex].text.split(' — ')[0]+' melebihi stok.'); return; }
   }
   if (type.value === 'Dine-In' && !form.querySelector('[name="nomor_meja"]').value.trim()) { ev.preventDefault(); alert('Nomor meja wajib diisi untuk Dine-In.'); }
 });
 update();
})();