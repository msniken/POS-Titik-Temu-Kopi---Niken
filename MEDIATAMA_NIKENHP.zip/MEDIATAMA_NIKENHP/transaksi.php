<?php
require __DIR__.'/config.php'; require_login();
if (($_SESSION['user']['role'] ?? '') !== 'kasir') { flash('Menu Transaksi Baru hanya dapat digunakan oleh akun Kasir.', 'error'); redirect('index.php'); }
require __DIR__.'/partials.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf();
 try {
  $type=$_POST['tipe_pesanan']??'Takeaway'; $table=trim($_POST['nomor_meja']??''); $customer=trim($_POST['nama_pemesan']??'');
  $method=$_POST['metode_bayar']??'Tunai'; $discount=max(0,(float)($_POST['diskon']??0));
  $ids=$_POST['product_id']??[]; $qtys=$_POST['qty']??[]; $notes=$_POST['catatan']??[];
  if(!in_array($type,['Dine-In','Takeaway'],true)) throw new Exception('Tipe pesanan tidak valid.');
  if($type==='Dine-In' && $table==='') throw new Exception('Nomor meja wajib diisi untuk Dine-In.');
  if(!in_array($method,['Tunai','QRIS','Transfer Bank','Kartu Debit'],true)) throw new Exception('Metode pembayaran tidak valid.');
  if(!is_array($ids)||!is_array($qtys)||count($ids)===0) throw new Exception('Tambahkan minimal satu menu.');
  $items=[]; $subtotal=0;
  foreach($ids as $i=>$pid){
   $pid=(int)$pid; $qty=(int)($qtys[$i]??0);
   if($pid<1||$qty<1) continue;
   $stmt=$pdo->prepare('SELECT id,nama_produk,harga_jual,stok FROM products WHERE id=? FOR UPDATE');
   // Lock is applied again inside transaction below; this first read only validates input.
   $stmt->execute([$pid]); $p=$stmt->fetch();
   if(!$p) throw new Exception('Ada menu yang tidak ditemukan.');
   $items[]=['id'=>$pid,'qty'=>$qty,'note'=>trim($notes[$i]??'')]; 
  }
  if(!$items) throw new Exception('Isi kuantitas menu dengan benar.');
  $pdo->beginTransaction();
  $subtotal=0; $prepared=[];
  foreach($items as $item){
   $stmt=$pdo->prepare('SELECT id,nama_produk,harga_jual,stok FROM products WHERE id=? FOR UPDATE');
   $stmt->execute([$item['id']]); $p=$stmt->fetch();
   if(!$p) throw new Exception('Menu tidak ditemukan.');
   if((int)$p['stok']<$item['qty']) throw new Exception('Stok '.$p['nama_produk'].' tidak mencukupi. Stok tersedia: '.$p['stok']);
   $line=(float)$p['harga_jual']*$item['qty']; $subtotal+=$line;
   $prepared[]=$item+['name'=>$p['nama_produk'],'price'=>(float)$p['harga_jual'],'line'=>$line];
  }
  $discount=min($discount,$subtotal); $tax=round(($subtotal-$discount)*0.10,2); $grand=$subtotal-$discount+$tax;
  $paid=max(0,(float)($_POST['uang_dibayar']??0));
  if($method==='Tunai' && $paid<$grand) throw new Exception('Uang tunai kurang dari total tagihan.');
  if($method!=='Tunai') $paid=$grand;
  $change=$method==='Tunai'?$paid-$grand:0;
  $invoice='INV-POS-'.date('Ymd').'-'.str_pad((string)random_int(1,9999),4,'0',STR_PAD_LEFT);
  $check=$pdo->prepare('SELECT id FROM orders WHERE invoice_number=?'); $check->execute([$invoice]);
  while($check->fetch()){ $invoice='INV-POS-'.date('Ymd').'-'.str_pad((string)random_int(1,9999),4,'0',STR_PAD_LEFT); $check->execute([$invoice]); }
  $stmt=$pdo->prepare("INSERT INTO orders(invoice_number,user_id,tipe_pesanan,nomor_meja,nama_pemesan,total_subtotal,pajak_nominal,diskon_nominal,grand_total,metode_bayar,uang_dibayar,uang_kembali,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?, 'Selesai')");
  $stmt->execute([$invoice,$_SESSION['user']['id'],$type,$type==='Dine-In'?$table:null,$customer?:null,$subtotal,$tax,$discount,$grand,$method,$paid,$change]);
  $orderId=(int)$pdo->lastInsertId();
  $detail=$pdo->prepare('INSERT INTO order_details(order_id,product_id,harga_satuan,kuantiti,subtotal_baris,catatan_khusus) VALUES(?,?,?,?,?,?)');
  $stock=$pdo->prepare('UPDATE products SET stok=stok-? WHERE id=?');
  foreach($prepared as $it){$detail->execute([$orderId,$it['id'],$it['price'],$it['qty'],$it['line'],$it['note']?:null]);$stock->execute([$it['qty'],$it['id']]);}
  $pdo->commit(); redirect('struk.php?id='.$orderId);
 } catch(Throwable $ex) {
  if($pdo->inTransaction()) $pdo->rollBack();
  flash($ex->getMessage(),'error'); redirect('transaksi.php');
 }
}
$products=$pdo->query("SELECT p.*,c.nama_kategori FROM products p JOIN categories c ON c.id=p.category_id WHERE p.stok>0 ORDER BY c.nama_kategori,p.nama_produk")->fetchAll();
header_ui('Transaksi Baru','transaksi');
?>
<form method="post" id="order-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
<div class="order-layout"><section class="panel order-main"><div class="panel-heading"><div><h3>Detail Pesanan</h3><p class="muted">Pilih jenis pesanan dan menu pelanggan.</p></div><span class="tag">POS</span></div>
<div class="form-grid"><div><label>Tipe Pesanan</label><select name="tipe_pesanan" id="order-type"><option>Takeaway</option><option>Dine-In</option></select></div><div id="table-field" class="hidden"><label>Nomor Meja *</label><input name="nomor_meja" placeholder="Contoh: A-03"></div><div><label>Nama Pemesan</label><input name="nama_pemesan" placeholder="Nama pelanggan (opsional)"></div></div>
<div class="section-label">ITEM PESANAN</div><div id="items">
<div class="order-item"><div class="item-fields"><div class="field-wide"><label>Menu</label><select name="product_id[]" class="product-select" required><option value="">Pilih menu...</option><?php foreach($products as $p): ?><option value="<?=$p['id']?>" data-price="<?=$p['harga_jual']?>" data-stock="<?=$p['stok']?>"><?=e($p['nama_produk'])?> — <?=rupiah($p['harga_jual'])?> (stok <?=$p['stok']?>)</option><?php endforeach; ?></select></div><div><label>Qty</label><input name="qty[]" type="number" class="qty-input" min="1" value="1" required></div><div><label>Catatan</label><input name="catatan[]" placeholder="Less sugar..."></div></div><button type="button" class="remove-item" title="Hapus item">×</button><div class="line-total muted">Subtotal: Rp 0</div></div>
</div><button type="button" class="btn btn-light" id="add-item">＋ Tambah Item</button>
</section><aside class="panel summary-panel"><h3>Ringkasan Pembayaran</h3><div class="summary-line"><span>Subtotal</span><b id="subtotal-view">Rp 0</b></div><div class="summary-line"><span>Diskon (Rp)</span><input class="discount-input" type="number" name="diskon" id="discount" min="0" value="0"></div><div class="summary-line"><span>Pajak restoran (10%)</span><b id="tax-view">Rp 0</b></div><div class="grand-total"><span>Total Tagihan</span><strong id="grand-view">Rp 0</strong></div>
<label>Metode Pembayaran</label><select name="metode_bayar" id="payment-method"><option>Tunai</option><option>QRIS</option><option>Transfer Bank</option><option>Kartu Debit</option></select>
<div id="cash-fields"><label>Uang Dibayar (Rp)</label><input name="uang_dibayar" id="paid" type="number" min="0" value="0"><div class="summary-line"><span>Kembalian</span><b id="change-view">Rp 0</b></div></div>
<button class="btn full submit-order" type="submit">Simpan & Cetak Struk</button><p class="fine-print">Stok divalidasi ulang sebelum transaksi disimpan.</p></aside></div></form>
<?php footer_ui(); ?>
