<?php
require __DIR__.'/config.php';
if (!empty($_SESSION['user'])) redirect('index.php');
$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare('SELECT id,username,password_hash,nama_lengkap,role,status FROM users WHERE username=? LIMIT 1');
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && (int)$user['status'] === 1 && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id'=>(int)$user['id'],'username'=>$user['username'],'name'=>$user['nama_lengkap'],'role'=>$user['role']];
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
        redirect('index.php');
    }
    $error = 'Username atau password salah, atau akun tidak aktif.';
}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login POS</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="login-page"><main class="login-card"><div class="login-brand-row"><div class="brand-mark">☕</div><div><p class="eyebrow">TITIK TEMU KOPI</p><p class="login-brand-sub">Kopi • Makanan • Cerita</p></div><span class="login-food">🥐</span></div><h1>Selamat datang</h1><p class="muted">Masuk untuk mengelola transaksi kafe.</p>
<?php if($error): ?><div class="alert error"><?=e($error)?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><label>Username</label><input name="username" required autocomplete="username" autofocus><label>Password</label><input type="password" name="password" required autocomplete="current-password"><button class="btn full">Masuk ke Dashboard</button></form>
