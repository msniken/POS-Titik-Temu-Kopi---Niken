<?php
require __DIR__.'/config.php';
require_admin();
require __DIR__.'/partials.php';

$error = '';
$editing = null;
$editId = (int)($_GET['edit'] ?? 0);
if ($editId > 0) {
    $stmt = $pdo->prepare('SELECT id, username, nama_lengkap, role, status FROM users WHERE id = ?');
    $stmt->execute([$editId]);
    $editing = $stmt->fetch();
    if (!$editing) { flash('Akun tidak ditemukan.', 'error'); redirect('users.php'); }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);
            $username = trim($_POST['username'] ?? '');
            $name = trim($_POST['nama_lengkap'] ?? '');
            $role = $_POST['role'] ?? 'kasir';
            $status = isset($_POST['status']) ? 1 : 0;
            $password = (string)($_POST['password'] ?? '');
            if (!preg_match('/^[A-Za-z0-9_.-]{3,60}$/', $username)) throw new Exception('Username 3–60 karakter, hanya huruf, angka, titik, garis bawah, atau tanda hubung.');
            if ($name === '' || mb_strlen($name) > 120) throw new Exception('Nama lengkap wajib diisi dan maksimal 120 karakter.');
            if (!in_array($role, ['admin','kasir'], true)) throw new Exception('Role tidak valid.');
            if ($id === 0 && strlen($password) < 4) throw new Exception('Password akun baru minimal 4 karakter.');
            if ($id > 0 && $id === (int)$_SESSION['user']['id'] && ($role !== 'admin' || $status !== 1)) throw new Exception('Akun Admin yang sedang digunakan tidak boleh diturunkan rolenya atau dinonaktifkan.');
            $check = $pdo->prepare('SELECT id FROM users WHERE username = ? AND id <> ?');
            $check->execute([$username, $id]);
            if ($check->fetch()) throw new Exception('Username sudah digunakan. Silakan pilih username lain.');
            if ($id > 0) {
                $old = $pdo->prepare('SELECT id, role, status FROM users WHERE id = ?'); $old->execute([$id]); $oldUser = $old->fetch();
                if (!$oldUser) throw new Exception('Akun yang akan diubah tidak ditemukan.');
                if ($oldUser['role'] === 'admin' && (int)$oldUser['status'] === 1 && ($role !== 'admin' || $status !== 1)) {
                    $admins = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin' AND status=1")->fetchColumn();
                    if ($admins <= 1) throw new Exception('Minimal harus ada satu akun Admin aktif.');
                }
                if ($password !== '') {
                    if (strlen($password) < 4) throw new Exception('Password baru minimal 4 karakter.');
                    $stmt = $pdo->prepare('UPDATE users SET username=?, nama_lengkap=?, role=?, status=?, password_hash=? WHERE id=?');
                    $stmt->execute([$username, $name, $role, $status, password_hash($password, PASSWORD_DEFAULT), $id]);
                } else {
                    $stmt = $pdo->prepare('UPDATE users SET username=?, nama_lengkap=?, role=?, status=? WHERE id=?');
                    $stmt->execute([$username, $name, $role, $status, $id]);
                }
                if ($id === (int)$_SESSION['user']['id']) {
                    $_SESSION['user']['username'] = $username;
                    $_SESSION['user']['name'] = $name;
                }
                flash('Data akun berhasil diperbarui.');
            } else {
                $stmt = $pdo->prepare('INSERT INTO users(username,password_hash,nama_lengkap,role,status) VALUES(?,?,?,?,?)');
                $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT), $name, $role, $status]);
                flash('Akun pengguna baru berhasil dibuat.');
            }
            redirect('users.php');
        }
        if ($action === 'toggle') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id === (int)$_SESSION['user']['id']) throw new Exception('Akun yang sedang digunakan tidak dapat dinonaktifkan.');
            $stmt = $pdo->prepare('SELECT id, role, status FROM users WHERE id=?'); $stmt->execute([$id]); $target = $stmt->fetch();
            if (!$target) throw new Exception('Akun tidak ditemukan.');
            $newStatus = (int)$target['status'] === 1 ? 0 : 1;
            if ($target['role'] === 'admin' && (int)$target['status'] === 1 && $newStatus === 0) {
                $admins = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin' AND status=1")->fetchColumn();
                if ($admins <= 1) throw new Exception('Minimal harus ada satu akun Admin aktif.');
            }
            $stmt = $pdo->prepare('UPDATE users SET status=? WHERE id=?'); $stmt->execute([$newStatus, $id]);
            flash($newStatus ? 'Akun berhasil diaktifkan.' : 'Akun berhasil dinonaktifkan.');
            redirect('users.php');
        }
        throw new Exception('Aksi tidak dikenali.');
    } catch (Throwable $ex) {
        $error = $ex instanceof PDOException && $ex->getCode() === '23000' ? 'Username sudah digunakan.' : $ex->getMessage();
        if (($_POST['action'] ?? '') === 'save' && (int)($_POST['id'] ?? 0) > 0) {
            $stmt = $pdo->prepare('SELECT id, username, nama_lengkap, role, status FROM users WHERE id=?');
            $stmt->execute([(int)$_POST['id']]); $editing = $stmt->fetch() ?: null;
        }
    }
}

$users = $pdo->query('SELECT id, username, nama_lengkap, role, status, created_at FROM users ORDER BY role ASC, nama_lengkap ASC')->fetchAll();
header_ui('Kelola Akun Pengguna', 'users');
?>
<div class="content-grid account-grid">
  <section class="panel">
    <div class="panel-heading"><div><h3><?= $editing ? 'Ubah Akun Pengguna' : 'Tambah Akun Pengguna' ?></h3><p class="muted">Buat akun Admin atau Kasir untuk pegawai kafe.</p></div></div>
    <?php if ($error): ?><div class="alert error"><?=e($error)?></div><?php endif; ?>
    <form method="post" class="stack-form">
      <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?=e($editing['id'] ?? 0)?>">
      <label for="username">Username</label><input id="username" name="username" maxlength="60" value="<?=e($editing['username'] ?? '')?>" placeholder="Contoh: kasir2" required>
      <label for="nama_lengkap">Nama lengkap / nama kasir</label><input id="nama_lengkap" name="nama_lengkap" maxlength="120" value="<?=e($editing['nama_lengkap'] ?? '')?>" placeholder="Contoh: Niken" required>
      <label for="role">Role / Hak Akses</label><select id="role" name="role"><option value="kasir" <?=($editing['role'] ?? 'kasir')==='kasir'?'selected':''?>>Kasir</option><option value="admin" <?=($editing['role'] ?? '')==='admin'?'selected':''?>>Admin</option></select>
      <label for="password">Password <?= $editing ? '(kosongkan jika tidak diubah)' : '' ?></label><input id="password" name="password" type="password" minlength="4" <?= $editing ? '' : 'required' ?> autocomplete="new-password" placeholder="Minimal 4 karakter">
      <label class="account-status"><input type="checkbox" name="status" value="1" <?=!isset($editing['status']) || (int)$editing['status']===1?'checked':''?>> Akun aktif dan dapat login</label>
      <div class="actions"><button class="btn" type="submit"><?= $editing ? 'Simpan Perubahan' : 'Buat Akun' ?></button><?php if($editing): ?><a class="btn btn-light" href="users.php">Batal</a><?php endif; ?></div>
    </form>
    <p class="fine-print account-note">Password disimpan dalam bentuk hash yang aman, bukan teks biasa.</p>
  </section>
  <section class="panel account-guide"><div class="panel-heading"><div><h3>Perbedaan Role</h3><p class="muted">Hak akses tiap akun.</p></div></div>
    <div class="stock-row"><div><b>Admin</b><small>Dashboard, laporan, menu & stok, dan kelola akun pengguna.</small></div><span class="tag">Pengelola</span></div>
    <div class="stock-row"><div><b>Kasir</b><small>Dashboard dan transaksi baru untuk melayani pesanan pelanggan.</small></div><span class="tag">Operasional</span></div>
  </section>
</div>
<section class="panel table-panel"><div class="panel-heading"><div><h3>Daftar Akun</h3><p class="muted"><?=count($users)?> akun terdaftar</p></div></div><div class="table-wrap"><table><thead><tr><th>Nama</th><th>Username</th><th>Role</th><th>Status</th><th>Dibuat</th><th>Aksi</th></tr></thead><tbody>
<?php if(!$users): ?><tr><td colspan="6" class="empty-cell">Belum ada akun.</td></tr><?php endif; foreach($users as $u): ?><tr><td><b><?=e($u['nama_lengkap'])?></b></td><td class="mono"><?=e($u['username'])?></td><td><?=e(ucfirst($u['role']))?></td><td><span class="status <?=$u['status']?'selesai':'dibatalkan'?>"><?=$u['status']?'Aktif':'Nonaktif'?></span></td><td><?=date('d/m/Y',strtotime($u['created_at']))?></td><td><div class="actions"><a href="users.php?edit=<?=$u['id']?>">Edit</a><?php if((int)$u['id']!==(int)$_SESSION['user']['id']): ?><form method="post" class="inline-action" onsubmit="return confirm('Yakin ingin <?=$u['status']?'menonaktifkan':'mengaktifkan'?> akun ini?')"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?=$u['id']?>"><button type="submit" class="link-button <?=$u['status']?'danger-link':''?>"><?=$u['status']?'Nonaktifkan':'Aktifkan'?></button></form><?php endif; ?></div></td></tr><?php endforeach; ?>
</tbody></table></div></section>
<?php footer_ui(); ?>
